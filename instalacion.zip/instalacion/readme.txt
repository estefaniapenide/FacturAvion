La carpeta instalación contiene:

	La carpeta facturación
	Script SQL
	La carpeta archivosmodificados con contenido que deberás añadir posteriormente.

La carpeta facturación contiene:

	#application/helper
		2 helpers extra en la carpeta usados en los módulos de provider e invoices_provider.

	#application/modules
		Los módulos completos de proveedores, facturas de proveedores, pagos a proveedores y modelo 303

	#application/modules/custom_fields 
		2 modelos extra al modulo custom_fields 

	#application/languages
		Carpeta de idiomas Spanish y english archivos necesarios (uno a editar por idioma, otro a añadir).

	#uploads/
		Carpeta provider_files en uploads/ para los archivos adjuntos de proveedores.

Paso 1: Base de datos:

	Carga el archivo sql en tu base de datos.

Paso 2: Copiado de archivos y carpetas:

	***** Si tienes una instalación limpia de invoiceplane 1.5.11 y no quieres editar cada archivo del paso 3 ******
		Copia la carpeta instalacionautomatica/facturacion en tu invoiceplane 
		
		#application/config/config.php
			Añade la linea: $config['enable_invoice_provider_deletion'] = true;
	
		No hagas el Paso 3
	
	***** Si no tienes una instalacion limpia o prefieres ir editando cada archivo por separado ******
		Copia y combina las carpetas de instalacion/application, salvo /languages en tu instalación de invoiceplane. No sobreescribirá nada, solo añadirá archivos y carpetas nuevos.
		Sigue con el Paso 3

Paso 3: Edición de archivos ya existentes en invoiceplane:

	#application/config/config.php
	Añade la linea: $config['enable_invoice_provider_deletion'] = true;
	
	#application/modules/custom_fields/controllers/Custom_fields.php
	En la función form() 
		Añadir en una linea despues de $this->load->model('mdl_user_custom'); 
		       $this->load->model('mdl_payment_custom_provider');
	
	#application/modules/custom_fields/views/form.php:
	En array $positions añadir el campo: 'payment_provider' => Mdl_payment_custom_provider::$positions
	
	#application/modules/filters/controllers/Ajax.php:
	Inserta las funciones del archivo archivosmodificados/Ajax.php (lineas 85 a 127)
		filter_invoices_provider() 
		filter_providers()
	
	#application/modules/layout/views/includes/head.php
	Inserta las funciones del archivo archivosmodificados/head.php (lineas 51 a 81)
		'.create-invoice-provider', function () 
		'#btn_copy_invoice_provider', function ()
		'.provider-create-invoice', function ()
		'add-file-provider', function ()
		'.invoice-add-payment-provider', function ()

	#application/modules/layout/views/includes/navbar.php
	Inserta las funciones disponibles en archivosmodificados/navbar.php
	Despues del <li> de clients añade el <li> de providers  (lineas 28 a 38)
	Despues del <li> de invoices añade el <li> de invoices_providers (lineas 64 a 74)
	Añadir en el <ul> del dropdown menu de payments los 4 <li> (lineas 86 a 89)
	Añadir en el <ul> del dropdown de reports los 2 <li> (lineas 133 a 135)
	
	#application/modules/products/controllers/Ajax.php
	Inserta en public function modal_product_lookups():
		En una linea despues de: $this->load->model('families/mdl_families');
			$this->load->model('providers/mdl_providers');
		En una linea despues de: $families = $this->mdl_families->get()->result();
			$providers = $this->mdl_products->get()->result();
		En una linea despues de: 'families' => $families,
			'providers' => $providers,
	
	#application/modules/products/controllers/Products.php
	En la función form()
		En una linea despues de: $this->load->model('families/mdl_families');
			$this->load->model('providers/mdl_providers');
		En una linea despues de: 'families' => $this->mdl_families->get()->result(),
                	'providers' => $this->mdl_providers->get()->result(),
	
	#application/modules/products/models/Mdl_products.php
	En la función default_order_by()
		Añade $this->db->order_by('ip_providers.provider_name, ip_products.product_name');
	En la función default_join()
		Añade $this->db->join('ip_providers', 'ip_providers.provider_id = ip_products.provider_id', 'left');
	Añade la función 
		public function by_provider($match)
		    {
			$this->db->where('ip_products.provider_id', $match);
		    }
	Comenta en la función validation_rules()
		'provider_name' => array(
                'field' => 'provider_name',
                'label' => trans('provider_name'),
                'rules' => ''
            	),
        Añade en la función validation_rules()
        	'provider_id' => array(
                'field' => 'provider_id',
                'label' => trans('provider'),
                'rules' => 'numeric'
            	),
         Añade en la función db_array()
         	$db_array['provider_id'] = (empty($db_array['provider_id']) ? null : $db_array['provider_id']);   	
        
        #application/modules/products/views/form.php
        	Comenta o elimina 
        	
        	  <div class="form-group">
                            <label for="provider_name">
                                <?php _trans('provider_name'); ?>
                            </label>

                            <input type="text" name="provider_name" id="provider_name" class="form-control"
                                   value="<?php echo $this->mdl_products->form_value('provider_name', true); ?>">
                </div>
                
                En su lugar pon:
                
                <div class="form-group">
                        <select name="provider_id" id="provider_id" class="form-control simple-select">
                                <option value="0"><?php _trans('select_provider'); ?></option>
                                <?php foreach ($providers as $provider) { ?>
                                    <option value="<?php echo $provider->provider_id; ?>"
                                        <?php check_select($this->mdl_products->form_value('provider_id'), $provider->provider_id) ?>
                                    ><?php echo $provider->provider_name; ?></option>
                                <?php } ?>
                            </select>
                    </div>

Paso 4: Idiomas

	Añade las lineas correspondientes en languages/Spanish/custom_lang.php y/o languages/english/custom_lang.php de los archivos ubicados en instalacion/facturacion/languages/{idioma}
	Copia el archivo Spanish/paginate_lang a tu directorio de idioma español de invoiceplane languages/Spanish/
