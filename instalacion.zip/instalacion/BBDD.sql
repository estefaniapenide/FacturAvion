-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 19-10-2022 a las 10:13:16
-- Versión del servidor: 5.7.33-0ubuntu0.16.04.1
-- Versión de PHP: 7.0.33-0ubuntu0.16.04.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `mtoffice`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_invoices_provider`
--

CREATE TABLE `ip_invoices_provider` (
  `invoice_provider_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `invoice_group_id` int(11) NOT NULL,
  `invoice_provider_status_id` tinyint(2) NOT NULL DEFAULT '1',
  `is_read_only` tinyint(1) DEFAULT NULL,
  `invoice_provider_password` varchar(90) DEFAULT NULL,
  `invoice_provider_date_created` date NOT NULL,
  `invoice_provider_date_modified` datetime NOT NULL,
  `invoice_provider_date_due` date NOT NULL,
  `invoice_provider_number` varchar(200) NOT NULL,
  `invoice_provider_discount_amount` decimal(20,2) DEFAULT NULL,
  `invoice_provider_discount_percent` decimal(20,2) DEFAULT NULL,
  `invoice_provider_terms` longtext NOT NULL,
  `invoice_provider_url_key` char(32) NOT NULL,
  `payment_method` int(11) NOT NULL DEFAULT '0',
  `creditinvoice_parent_id` int(11) DEFAULT NULL,
  `invoice_provider_pdf` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ip_invoice_groups`
--

INSERT INTO `ip_invoice_groups` (`invoice_group_id`, `invoice_group_name`, `invoice_group_identifier_format`, `invoice_group_next_id`, `invoice_group_left_pad`) VALUES
(465, 'facturas proveedor', '{{{id}}}', 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_invoice_provider_amounts`
--

CREATE TABLE `ip_invoice_provider_amounts` (
  `invoice_provider_amount_id` int(11) NOT NULL,
  `invoice_provider_id` int(11) NOT NULL,
  `invoice_provider_sign` enum('1','-1') NOT NULL DEFAULT '1',
  `invoice_provider_item_subtotal` decimal(20,2) DEFAULT '0.00',
  `invoice_provider_item_tax_total` decimal(20,2) DEFAULT '0.00',
  `invoice_provider_tax_total` decimal(20,2) DEFAULT '0.00',
  `invoice_provider_total` decimal(20,2) DEFAULT '0.00',
  `invoice_provider_paid` decimal(20,2) DEFAULT '0.00',
  `invoice_provider_balance` decimal(20,2) DEFAULT '0.00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_invoice_provider_custom`
--

CREATE TABLE `ip_invoice_provider_custom` (
  `invoice_provider_custom_id` int(11) NOT NULL,
  `invoice_provider_id` int(11) NOT NULL,
  `invoice_custom_fieldid` int(11) NOT NULL,
  `invoice_custom_fieldvalue` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_invoice_provider_items`
--

CREATE TABLE `ip_invoice_provider_items` (
  `item_id` int(11) NOT NULL,
  `invoice_provider_id` int(11) NOT NULL,
  `item_tax_rate_id` int(11) NOT NULL DEFAULT '0',
  `item_product_id` int(11) DEFAULT NULL,
  `item_date_added` date NOT NULL,
  `item_task_id` int(11) DEFAULT NULL,
  `item_name` text,
  `item_description` longtext,
  `item_quantity` decimal(10,2) NOT NULL,
  `item_price` decimal(20,2) DEFAULT NULL,
  `item_discount_amount` decimal(20,2) DEFAULT NULL,
  `item_order` int(2) NOT NULL DEFAULT '0',
  `item_product_unit` varchar(50) DEFAULT NULL,
  `item_product_unit_id` int(11) DEFAULT NULL,
  `item_date` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_invoice_provider_item_amounts`
--

CREATE TABLE `ip_invoice_provider_item_amounts` (
  `item_amount_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_subtotal` decimal(20,2) NOT NULL,
  `item_tax_total` decimal(20,2) NOT NULL,
  `item_discount` decimal(20,2) DEFAULT NULL,
  `item_total` decimal(20,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_invoice_provider_tax_rates`
--

CREATE TABLE `ip_invoice_provider_tax_rates` (
  `invoice_provider_tax_rate_id` int(11) NOT NULL,
  `invoice_provider_id` int(11) NOT NULL,
  `tax_rate_id` int(11) NOT NULL,
  `include_item_tax` int(1) NOT NULL DEFAULT '0',
  `invoice_provider_tax_rate_amount` decimal(10,2) NOT NULL DEFAULT '0.00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_payments_provider`
--

CREATE TABLE `ip_payments_provider` (
  `payment_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL DEFAULT '0',
  `payment_date` date NOT NULL,
  `payment_amount` decimal(20,2) DEFAULT NULL,
  `payment_note` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_payment_custom_provider`
--

CREATE TABLE `ip_payment_custom_provider` (
  `payment_custom_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `payment_custom_fieldid` int(11) NOT NULL,
  `payment_custom_fieldvalue` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_providers`
--

CREATE TABLE `ip_providers` (
  `provider_id` int(11) NOT NULL,
  `provider_date_created` datetime NOT NULL,
  `provider_date_modified` datetime NOT NULL,
  `provider_name` text,
  `provider_comercial_name` text,
  `provider_address_1` text,
  `provider_address_2` text,
  `provider_city` text,
  `provider_state` text,
  `provider_zip` text,
  `provider_country` text,
  `provider_phone` text,
  `provider_mobile` text,
  `provider_email` text,
  `provider_web` text,
  `provider_vat_id` text,
  `provider_language` varchar(255) DEFAULT 'system',
  `provider_active` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_provider_custom`
--

CREATE TABLE `ip_provider_custom` (
  `provider_custom_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `provider_custom_fieldid` int(11) NOT NULL,
  `provider_custom_fieldvalue` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_provider_notes`
--

CREATE TABLE `ip_provider_notes` (
  `provider_note_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `provider_note_date` date NOT NULL,
  `provider_note` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ip_settings`
--

INSERT INTO `ip_settings` (`setting_key`, `setting_value`) VALUES
('read_only_toggle_provider', '3');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_uploads_provider`
--

CREATE TABLE `ip_uploads_provider` (
  `upload_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `url_key` char(32) NOT NULL,
  `file_name_original` longtext NOT NULL,
  `file_name_new` longtext NOT NULL,
  `uploaded_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ip_user_providers`
--

CREATE TABLE `ip_user_providers` (
  `user_provider_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ip_invoices_provider`
--
ALTER TABLE `ip_invoices_provider`
  ADD PRIMARY KEY (`invoice_provider_id`),
  ADD UNIQUE KEY `invoice_provider_url_key` (`invoice_provider_url_key`),
  ADD KEY `user_id` (`user_id`,`provider_id`,`invoice_provider_date_created`,`invoice_provider_date_due`,`invoice_provider_number`),
  ADD KEY `invoice_provider_status_id` (`invoice_provider_status_id`);

--
-- Indices de la tabla `ip_invoice_provider_amounts`
--
ALTER TABLE `ip_invoice_provider_amounts`
  ADD PRIMARY KEY (`invoice_provider_amount_id`),
  ADD KEY `invoice_provider_id` (`invoice_provider_id`),
  ADD KEY `invoice_provider_paid` (`invoice_provider_paid`,`invoice_provider_balance`);

--
-- Indices de la tabla `ip_invoice_provider_custom`
--
ALTER TABLE `ip_invoice_provider_custom`
  ADD PRIMARY KEY (`invoice_provider_custom_id`),
  ADD KEY `invoice_provider_id` (`invoice_provider_id`);

--
-- Indices de la tabla `ip_invoice_provider_items`
--
ALTER TABLE `ip_invoice_provider_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `invoice_provider_id` (`invoice_provider_id`,`item_tax_rate_id`,`item_date_added`,`item_order`);

--
-- Indices de la tabla `ip_invoice_provider_item_amounts`
--
ALTER TABLE `ip_invoice_provider_item_amounts`
  ADD PRIMARY KEY (`item_amount_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indices de la tabla `ip_invoice_provider_tax_rates`
--
ALTER TABLE `ip_invoice_provider_tax_rates`
  ADD PRIMARY KEY (`invoice_provider_tax_rate_id`),
  ADD KEY `invoice_provider_id` (`invoice_provider_id`,`tax_rate_id`);

--
-- Indices de la tabla `ip_payments_provider`
--
ALTER TABLE `ip_payments_provider`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `payment_method_id` (`payment_method_id`),
  ADD KEY `payment_amount` (`payment_amount`);

--
-- Indices de la tabla `ip_payment_custom_provider`
--
ALTER TABLE `ip_payment_custom_provider`
  ADD PRIMARY KEY (`payment_custom_id`),
  ADD UNIQUE KEY `payment_id` (`payment_id`,`payment_custom_fieldid`);

--
-- Indices de la tabla `ip_providers`
--
ALTER TABLE `ip_providers`
  ADD PRIMARY KEY (`provider_id`),
  ADD KEY `provider_active` (`provider_active`);

--
-- Indices de la tabla `ip_provider_custom`
--
ALTER TABLE `ip_provider_custom`
  ADD PRIMARY KEY (`provider_custom_id`),
  ADD UNIQUE KEY `provider_id` (`provider_id`,`provider_custom_fieldid`);

--
-- Indices de la tabla `ip_provider_notes`
--
ALTER TABLE `ip_provider_notes`
  ADD PRIMARY KEY (`provider_note_id`),
  ADD KEY `provider_id` (`provider_id`,`provider_note_date`);

--
-- Indices de la tabla `ip_uploads_provider`
--
ALTER TABLE `ip_uploads_provider`
  ADD PRIMARY KEY (`upload_id`);

--
-- Indices de la tabla `ip_user_providers`
--
ALTER TABLE `ip_user_providers`
  ADD PRIMARY KEY (`user_provider_id`),
  ADD KEY `user_id` (`user_id`,`provider_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ip_invoices_provider`
--
ALTER TABLE `ip_invoices_provider`
  MODIFY `invoice_provider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
--
-- AUTO_INCREMENT de la tabla `ip_invoice_provider_amounts`
--
ALTER TABLE `ip_invoice_provider_amounts`
  MODIFY `invoice_provider_amount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;
--
-- AUTO_INCREMENT de la tabla `ip_invoice_provider_custom`
--
ALTER TABLE `ip_invoice_provider_custom`
  MODIFY `invoice_provider_custom_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `ip_invoice_provider_items`
--
ALTER TABLE `ip_invoice_provider_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT de la tabla `ip_invoice_provider_item_amounts`
--
ALTER TABLE `ip_invoice_provider_item_amounts`
  MODIFY `item_amount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT de la tabla `ip_invoice_provider_tax_rates`
--
ALTER TABLE `ip_invoice_provider_tax_rates`
  MODIFY `invoice_provider_tax_rate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT de la tabla `ip_payments_provider`
--
ALTER TABLE `ip_payments_provider`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT de la tabla `ip_payment_custom_provider`
--
ALTER TABLE `ip_payment_custom_provider`
  MODIFY `payment_custom_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `ip_providers`
--
ALTER TABLE `ip_providers`
  MODIFY `provider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de la tabla `ip_provider_custom`
--
ALTER TABLE `ip_provider_custom`
  MODIFY `provider_custom_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `ip_provider_notes`
--
ALTER TABLE `ip_provider_notes`
  MODIFY `provider_note_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `ip_uploads_provider`
--
ALTER TABLE `ip_uploads_provider`
  MODIFY `upload_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT de la tabla `ip_user_providers`
--
ALTER TABLE `ip_user_providers`
  MODIFY `user_provider_id` int(11) NOT NULL AUTO_INCREMENT;
  
ALTER TABLE ip_products ADD COLUMN provider_id INT(11) DEFAULT NULL;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
